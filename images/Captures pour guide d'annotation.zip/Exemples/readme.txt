Ce fichier comporte les descriptions associées aux exemples liés au guide d'annotation. Les exemples sont dans l'ordre de lecture du document original : https://hodaclm.github.io/resolco/

1. Section 1.2. Je ne sais pas s'il fallait le modifier mais je l'ai fait au cas où. L'annotation gold est légèrement différente de celle présentée dans l'exemple du guide.

2. Section 2.1. SP. Suppression phC, correction couleur.

Section 2.1. Noms. Ajouter un exemple (voir 30.)

3. Section 2.1. PP. Suppression phC.
Commentaire d'ajout d'exemples PP "Le président élu". Que faire ? (voir 31 et 31_bis)

4. Section 2.1. Plusieurs modifieurs. Correction couleur.
Commentaire d'ajout d'exemple modif. post-posés. Que faire ?

5. Section 2.1. Ce n'est pas la bonne copie. Le texte est tiré de UN-M2-2020-UCL-D1-R4-V1_N. Copie non annotée dans ressource.

6. Section 2.1. Correction couleur.

7. Section 2.1. J'ai quand même refait au cas où.

8. Section 2.2. Correction couleur.

Section 2.3. Commentaire d'ajout d'exemples. Que faire ? (Il y a déjà le détail des pronoms non ? Non commentés ceci dit)

9. Section 2.3.1. J'ai quand même refait au cas où.

10. Section 2.3.2. J'ai quand même refait au cas où.

Section 2.3.3. Ajouter exemples. (voir 32, 32_bis, 32_ter)

11. Section 2.3.4. Correction couleur. Suppression phC. Texte et annotations légèrement différents.

12. Section 2.3.4. Suppression phC. 

13. Section 2.3.5. J'ai quand même refait au cas où.
Commentaire indiquant qu'il faudrait la présence d'un maillon "l'autre" non présent dans cette copie. A chercher. (voir 13_bis et 13_ter)

13_bis. Proposition de remplacement pour 13. Copie : CO-4e-2018-LSPJJRD-D1-R10-V1

13_ter. Proposition de remplacement pour 13. Moins bon que 13_bis. Copie : CO-6e-2016-VTAC603-D1-R18-V1

Section 2.5. Orth. "Les maillons de forme NPP peuvent être composé". Ajouter un S.

14. Section 2.5. Correction couleur. Suppression phC.

Section 2.6. Absente !

15. Section 2.7. Correction couleur. 

16. Section 2.7. Suppression phC. 

17. Section 2.8.a. Correction couleur. On voit pas bien le texte avec les liens. A refaire ?

17_bis. Section 2.8.a. J'ai tenté un truc pour coller au commentaire.

18. Section 2.8.b. Ce n'est pas la bonne copie. Le texte est tiré de CO-3e-2016-VTAC305-D1-R6-V1. J'ai quand même refait au cas où.

19. Section 2.8.b. Il manque l'indication de la copie. Copie : EC-CM1-2015-TFGLX-D1-R12-V1. J'ai quand même refait au cas où. On voit pas bien le texte avec les liens. Attention légende et texte au-dessus : inverser couleurs CR_Il et CR_Elle.

20. Section 2.8.b. Attention légende : CR_Elle doit être en bleu. Suppression phC.

Attention, section suivante, encore 2.8 - "Remarques". Je présente l'exemple 21 dans cette section, renomée "2.9".

21. Section 2.9. "Remarques". Correction couleur. Suppression phC.

22. Section 3. Correction couleur. Suppression phC.

Attention, pour le § suivant, l'exemple suivant et le § le suivant, il faut modifier la couleur de "CR_Il"

23. Section 3. Suppression phC.

24. Section 3. Suppression phC.

25. Section 3.Suppression maillon candidat.

26. Section 3. Suppression maillons candidats.

Illustration commentaire "Membre de lesEnfants" ne nécessite pas de nouvelle capture.

27. Section 4.1. Correction couleur. Suppression phC.

28. Section 4.1.a. Correction couleur.

29. Section 4.1.a. Correction couleur.

Section 5.2.3. Faudrait peut-être refaire la capture de l'interface mais j'ai un peu la flemme.

30. Exemple pour modifieur nom. Copie : CO-3e-2018-FSBJC6-D1-R6-V1

31. Exemple pour 2.1 SN-PP. Copie : UN-M2-2020-UCL-D1-R118-V1

31_bis. Autre exemple. Copie : UN-M2-2020-UCL-D1-R124-V1

32. Exemple pronom indéfini : chacun. Copie : CO-3e-2016-VTAC305-D1-R19-V1

32_bis. Exemple pronom indéfini : aucun. Copie : CO-3e-2018-FSBJC6-D1-R4-V1

32_ter. Exemple pronom indéfini : personne. Copie : CO-3e-2018-FSBJC6-D1-R4-V1